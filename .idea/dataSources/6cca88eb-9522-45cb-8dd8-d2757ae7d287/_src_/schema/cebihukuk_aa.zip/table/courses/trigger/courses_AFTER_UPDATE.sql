CREATE TRIGGER courses_AFTER_UPDATE
AFTER UPDATE ON courses
FOR EACH ROW
  BEGIN

UPDATE admins as a
SET a.number_of_courses = a.number_of_courses + 1
WHERE a.admin_id = new.admin_id;

END;
