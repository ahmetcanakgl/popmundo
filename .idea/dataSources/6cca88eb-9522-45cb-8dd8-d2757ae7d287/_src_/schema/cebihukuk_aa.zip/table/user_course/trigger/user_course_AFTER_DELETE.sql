CREATE TRIGGER user_course_AFTER_DELETE
AFTER DELETE ON user_course
FOR EACH ROW
  BEGIN

UPDATE courses
SET number_of_users = number_of_users - 1
WHERE courses.course_id = old.course_id;

END;
