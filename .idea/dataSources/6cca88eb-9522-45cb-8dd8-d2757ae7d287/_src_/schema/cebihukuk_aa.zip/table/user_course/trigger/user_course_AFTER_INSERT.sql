CREATE TRIGGER user_course_AFTER_INSERT
AFTER INSERT ON user_course
FOR EACH ROW
  BEGIN

UPDATE courses
SET number_of_users = number_of_users + 1
WHERE courses.course_id = new.course_id;

END;
